package com.BeanValidator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeanValidatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
