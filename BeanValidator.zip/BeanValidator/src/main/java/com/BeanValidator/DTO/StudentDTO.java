package com.BeanValidator.DTO;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StudentDTO {

    @Size(min = 2,max = 8)
    @NotEmpty
    private String name;

    @NotNull
    private String location;

    @Min(18)
    @Max(40)
    private Integer age;

    @Email
    private String email;


}
