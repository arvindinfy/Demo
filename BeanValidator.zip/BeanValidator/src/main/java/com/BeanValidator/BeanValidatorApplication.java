package com.BeanValidator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeanValidatorApplication {

	public static void main(String[] args)
	{
		SpringApplication.run(BeanValidatorApplication.class, args);
	}

}
